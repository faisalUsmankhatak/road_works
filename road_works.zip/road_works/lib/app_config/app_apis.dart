class AppApis{
  static String BASE_URL="https://imrans24.sg-host.com/api/";
}