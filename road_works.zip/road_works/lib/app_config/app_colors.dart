
import 'package:flutter/material.dart';
class AppColors {
  static const primaryColor = Color(0xff4C4C4C);
  static const greyColor = Color(0xff9A9A9A);
  static const blackColor = Color(0xff4C4C4C);
  static const textFieldColor = Color(0xff747688);
  static const whiteColor = Color(0xffFFFFFF);
  static const profileTextFieldColor = Color(0xffD3D3D3);

}