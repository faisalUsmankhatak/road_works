import 'package:get/get.dart';

class MessageController extends GetxController {

  RxList<String> messages = [
    "Sure sir! i will design it.Tell me when you wantthis? ",
    "You have to design this, as soon as possible",
    "Ok sir, i will design this in 3 days. ",
    "And my budget is50\$ for all.",
    "Ok sir! then the deal is done in 50\$!",
    "Sure sir! i will design it.Tell me when you wantthis? ",
    "You have to design this, as soon as possible",
    "Ok sir, i will design this in 3 days. ",
    "And my budget is50\$ for all.",
    "Ok sir! then the deal is done in 50\$!",
  ].obs;

}