import 'package:flutter/material.dart';
import 'package:get/get.dart';
class AuthController extends GetxController{
RxBool isRememberMe=false.obs;
}