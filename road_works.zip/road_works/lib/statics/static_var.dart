import 'package:get/get.dart';
class StaticVariable{

  static double width = Get.width;
  static double height = Get.height;

}