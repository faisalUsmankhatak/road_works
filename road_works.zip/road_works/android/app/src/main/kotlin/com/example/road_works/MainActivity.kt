package com.example.road_works

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
